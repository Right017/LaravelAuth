<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">

    <title>Mini App</title>
  </head>
  
  <body>
    
    <div class="container">
        <br><h2 class="text-center">Edit Your Notes Here</h2><hr>
        <div class="row justify-content-center align-items-center h-100">
            <div class="col col-sm-6 col-md-6 col-lg-4 col-xl-3">
              <form action="<?php echo e(route('admin.crud')); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <div class="result">
                    <?php if(Session::get('success')): ?>            
                    <div class="alert alert-success" role="alert">
                        <?php echo e(Session::get('success')); ?>

                      </div>
                    <?php endif; ?>

                    <?php if(Session::get('fail')): ?>            
                    <div class="alert alert-danger" role="alert">
                        <?php echo e(Session::get('fail')); ?>

                      </div>
                    <?php endif; ?>
                </div>
                <input type="hidden" class="form-control" name="id" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($find['id']); ?>">
                    <div class="form-group ">
                      <label for="exampleInputEmail1">User Name</label>
                      <input type="text" class="form-control" name="edit_name" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($find['user_name']); ?>" required>
                    </div>
          
                    <div class="form-group">
                      <label for="exampleFormControlTextarea1">Notes</label>
                      <input type="text" class="form-control" name="edit_note" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($find['note']); ?>" required>
                    </div>
          
                  <button type="submit" class="btn btn-primary btn-sm btn-block">Update</button>
                </form>
      
            </div>
          </div>
        </div>
          
    



    </body>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

    
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
    
</html>


<?php /**PATH C:\xampp\htdocs\laravelLogin\resources\views/admin/editNote.blade.php ENDPATH**/ ?>
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\Member;
use App\Models\Note;

class userController extends Controller
{
    function login(){
        return view('/login');
    }

    function register(){
        return view('/register');
    }

    function create(Request $request){
        $request->validate([
            'name'=>'required',
            'mno'=>'required|min:10|max:12',
            'email'=>'required|email|unique:members',
            'password'=>'required|min:5|max:12',
            
        ]);

        $member= new Member;
        $member->name=$request->name;
        $member->mno=$request->mno;
        $member->email=$request->email;
        $member->password=Hash::make($request->password);

        $save=$member->save();

        if($save){
            return back()->with('success','You have been successfuly registered');
        }else{
            return back()->with('fail','Something went wrong Please try again');
        }
    }

    function check(Request $request){
        $request->validate([
            'email'=>'required|email',
            'password'=>'required|min:5|max:12',
        ]);

        $user = Member::where('email','=',$request->email)->first();

        if($user){
                if(Hash::check($request->password, $user->password)){
                    $request->session()->put('LoggedUser',$user->id);
                    return redirect('profile');
                }else{
                    return back()->with('fail','Invalid Password');
                }
        }else{
            return back()->with('fail','Invalid Email Address');
        }
    }

    function profile(){
        
        if(session()->has('LoggedUser')){
            $user=Member::where('id','=',session('LoggedUser'))->first();
            $data=[
                'LoggedUserInfo'=>$user
            ];
        }
        return view('admin.profile',$data);
    }

    function logout(){
        if(session()->has('LoggedUser')){
            session()->pull('LoggedUser');
            return redirect('login');
        }
    }

    function crud(){
        
        if(session()->has('LoggedUser')){
            $user=Member::where('id','=',session('LoggedUser'))->first();
            $data=[
                'LoggedUserInfo'=>$user
            ];
        }
        return view('admin.crud',$data);
    }

    function addNotes(Request $req){
        $member= new Note;
        $member->user_name=$req->user_name;
        $member->note=$req->notes;
        $add=$member->save();

        if($add){
            return back()->with('success','Note successfuly added');
        }else{
            return back()->with('fail','Something went wrong Please try again');
        }        
        
    }

    function showNotes(){
        //   $all=member::all() ;
        $all=Note::paginate(5);
        $user=Member::where('id','=',session('LoggedUser'))->first();
        $data=[
            'LoggedUserInfo'=>$user
        ];
          return view('admin.crud',['members'=>$all],$data);
          
      }

      function delete($id)
    {
        $all=Note::find($id);
        $all->delete();
        return redirect('/crud');    
    }

    // function editNote($id){
    //     $all=Note::find($id);
    //     $user=Member::where('id','=',session('LoggedUser'))->first();
    //     $data=[
    //         'LoggedUserInfo'=>$user
    //     ];
    //     return view('admin.crud',['data'=>$all],$data);

    //     // return Note::find($id);
    // }
    function editNote($id){
        
        if(session()->has('LoggedUser')){
            $user=Member::where('id','=',session('LoggedUser'))->first();
            $data=[
                'LoggedUserInfo'=>$user
            ];
        }
        $find=Note::find($id);
        
        return view('admin.editNote',['find'=>$find],$data);
    }

    function updateNote(Request $req){
        // return $req->input();
        $all=Note::find($req->id);
        $all->user_name=$req->edit_name;
        $all->note=$req->edit_note;

        $all->save();

        return redirect('/crud');    
        
    }


}

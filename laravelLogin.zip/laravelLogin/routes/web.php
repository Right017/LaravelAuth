<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\userController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('login',[userController::class,'login'])->middleware('AlreadyLoggedIn');
Route::get('register',[userController::class,'register'])->middleware('AlreadyLoggedIn');
Route::post('create',[userController::class,'create'])->name('auth.create');
Route::post('check',[userController::class,'check'])->name('auth.check');
Route::get('profile',[userController::class,'profile'])->middleware('isLogged');
Route::post('logout',[userController::class,'logout']);
Route::get('crud',[userController::class,'crud'])->middleware('isLogged');
Route::post('crud',[userController::class,'addNotes'])->name('admin.crud');
Route::get('crud',[userController::class,'showNotes'])->middleware('isLogged');
Route::get('delete/{id}',[userController::class,'delete']);
Route::get('editNote/{id}',[userController::class,'editNote'])->middleware('isLogged');
Route::post('crud',[userController::class,'updateNote'])->name('admin.crud');